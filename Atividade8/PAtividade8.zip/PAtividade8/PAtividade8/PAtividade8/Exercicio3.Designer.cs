﻿namespace PAtividade8
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEntrada = new System.Windows.Forms.Label();
            this.txtEntrada = new System.Windows.Forms.TextBox();
            this.btnPalin = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblEntrada
            // 
            this.lblEntrada.AutoSize = true;
            this.lblEntrada.Location = new System.Drawing.Point(92, 53);
            this.lblEntrada.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lblEntrada.Name = "lblEntrada";
            this.lblEntrada.Size = new System.Drawing.Size(115, 32);
            this.lblEntrada.TabIndex = 1;
            this.lblEntrada.Text = "Entrada";
            // 
            // txtEntrada
            // 
            this.txtEntrada.Location = new System.Drawing.Point(291, 46);
            this.txtEntrada.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.txtEntrada.Name = "txtEntrada";
            this.txtEntrada.Size = new System.Drawing.Size(260, 39);
            this.txtEntrada.TabIndex = 2;
            // 
            // btnPalin
            // 
            this.btnPalin.Location = new System.Drawing.Point(291, 193);
            this.btnPalin.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.btnPalin.Name = "btnPalin";
            this.btnPalin.Size = new System.Drawing.Size(260, 56);
            this.btnPalin.TabIndex = 3;
            this.btnPalin.Text = "Palíndromo?";
            this.btnPalin.UseVisualStyleBackColor = true;
            this.btnPalin.Click += new System.EventHandler(this.btnPalin_Click);
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(766, 429);
            this.Controls.Add(this.btnPalin);
            this.Controls.Add(this.txtEntrada);
            this.Controls.Add(this.lblEntrada);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.Name = "frmExercicio3";
            this.Text = "Exercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEntrada;
        private System.Windows.Forms.TextBox txtEntrada;
        private System.Windows.Forms.Button btnPalin;
    }
}