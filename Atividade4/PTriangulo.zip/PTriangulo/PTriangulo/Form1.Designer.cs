﻿
namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblLadoa = new System.Windows.Forms.Label();
            this.LblLadob = new System.Windows.Forms.Label();
            this.LblLadoc = new System.Windows.Forms.Label();
            this.TxtLadoa = new System.Windows.Forms.TextBox();
            this.TxtLadob = new System.Windows.Forms.TextBox();
            this.TxtLadoc = new System.Windows.Forms.TextBox();
            this.LblTriangulomodelo = new System.Windows.Forms.Label();
            this.BtnCalcular = new System.Windows.Forms.Button();
            this.MskbxModelo = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // LblLadoa
            // 
            this.LblLadoa.AutoSize = true;
            this.LblLadoa.Location = new System.Drawing.Point(95, 105);
            this.LblLadoa.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.LblLadoa.Name = "LblLadoa";
            this.LblLadoa.Size = new System.Drawing.Size(120, 37);
            this.LblLadoa.TabIndex = 0;
            this.LblLadoa.Text = "Lado A";
            // 
            // LblLadob
            // 
            this.LblLadob.AutoSize = true;
            this.LblLadob.Location = new System.Drawing.Point(97, 229);
            this.LblLadob.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.LblLadob.Name = "LblLadob";
            this.LblLadob.Size = new System.Drawing.Size(119, 37);
            this.LblLadob.TabIndex = 1;
            this.LblLadob.Text = "Lado B";
            // 
            // LblLadoc
            // 
            this.LblLadoc.AutoSize = true;
            this.LblLadoc.Location = new System.Drawing.Point(95, 363);
            this.LblLadoc.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.LblLadoc.Name = "LblLadoc";
            this.LblLadoc.Size = new System.Drawing.Size(121, 37);
            this.LblLadoc.TabIndex = 2;
            this.LblLadoc.Text = "Lado C";
            // 
            // TxtLadoa
            // 
            this.TxtLadoa.Location = new System.Drawing.Point(316, 98);
            this.TxtLadoa.Margin = new System.Windows.Forms.Padding(6);
            this.TxtLadoa.Name = "TxtLadoa";
            this.TxtLadoa.Size = new System.Drawing.Size(355, 44);
            this.TxtLadoa.TabIndex = 3;
            this.TxtLadoa.Validated += new System.EventHandler(this.TxtLadoa_Validated);
            // 
            // TxtLadob
            // 
            this.TxtLadob.Location = new System.Drawing.Point(316, 222);
            this.TxtLadob.Margin = new System.Windows.Forms.Padding(6);
            this.TxtLadob.Name = "TxtLadob";
            this.TxtLadob.Size = new System.Drawing.Size(355, 44);
            this.TxtLadob.TabIndex = 4;
            // 
            // TxtLadoc
            // 
            this.TxtLadoc.Location = new System.Drawing.Point(316, 356);
            this.TxtLadoc.Margin = new System.Windows.Forms.Padding(6);
            this.TxtLadoc.Name = "TxtLadoc";
            this.TxtLadoc.Size = new System.Drawing.Size(355, 44);
            this.TxtLadoc.TabIndex = 5;
            // 
            // LblTriangulomodelo
            // 
            this.LblTriangulomodelo.AutoSize = true;
            this.LblTriangulomodelo.Location = new System.Drawing.Point(15, 581);
            this.LblTriangulomodelo.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.LblTriangulomodelo.Name = "LblTriangulomodelo";
            this.LblTriangulomodelo.Size = new System.Drawing.Size(265, 37);
            this.LblTriangulomodelo.TabIndex = 7;
            this.LblTriangulomodelo.Text = "Triângulo Modelo";
            // 
            // BtnCalcular
            // 
            this.BtnCalcular.Location = new System.Drawing.Point(84, 445);
            this.BtnCalcular.Margin = new System.Windows.Forms.Padding(6);
            this.BtnCalcular.Name = "BtnCalcular";
            this.BtnCalcular.Size = new System.Drawing.Size(513, 90);
            this.BtnCalcular.TabIndex = 8;
            this.BtnCalcular.Text = "Calcular";
            this.BtnCalcular.UseVisualStyleBackColor = true;
            this.BtnCalcular.Click += new System.EventHandler(this.BtnCalcular_Click);
            // 
            // MskbxModelo
            // 
            this.MskbxModelo.Location = new System.Drawing.Point(334, 574);
            this.MskbxModelo.Name = "MskbxModelo";
            this.MskbxModelo.Size = new System.Drawing.Size(337, 44);
            this.MskbxModelo.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 37F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(696, 657);
            this.Controls.Add(this.MskbxModelo);
            this.Controls.Add(this.BtnCalcular);
            this.Controls.Add(this.LblTriangulomodelo);
            this.Controls.Add(this.TxtLadoc);
            this.Controls.Add(this.TxtLadob);
            this.Controls.Add(this.TxtLadoa);
            this.Controls.Add(this.LblLadoc);
            this.Controls.Add(this.LblLadob);
            this.Controls.Add(this.LblLadoa);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblLadoa;
        private System.Windows.Forms.Label LblLadob;
        private System.Windows.Forms.Label LblLadoc;
        private System.Windows.Forms.TextBox TxtLadoa;
        private System.Windows.Forms.TextBox TxtLadob;
        private System.Windows.Forms.TextBox TxtLadoc;
        private System.Windows.Forms.Label LblTriangulomodelo;
        private System.Windows.Forms.Button BtnCalcular;
        private System.Windows.Forms.MaskedTextBox MskbxModelo;
    }
}

