﻿
namespace PIMC
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblCalculeIMC = new System.Windows.Forms.Label();
            this.MskBxPeso = new System.Windows.Forms.MaskedTextBox();
            this.MskBxAltura = new System.Windows.Forms.MaskedTextBox();
            this.LblPeso = new System.Windows.Forms.Label();
            this.LblAltura = new System.Windows.Forms.Label();
            this.LblIMC = new System.Windows.Forms.Label();
            this.MskBxIMC = new System.Windows.Forms.MaskedTextBox();
            this.BtnCalcular = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblCalculeIMC
            // 
            this.LblCalculeIMC.AutoSize = true;
            this.LblCalculeIMC.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblCalculeIMC.Location = new System.Drawing.Point(334, 41);
            this.LblCalculeIMC.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.LblCalculeIMC.Name = "LblCalculeIMC";
            this.LblCalculeIMC.Size = new System.Drawing.Size(357, 40);
            this.LblCalculeIMC.TabIndex = 0;
            this.LblCalculeIMC.Text = "CALCULE SEU IMC";
            // 
            // MskBxPeso
            // 
            this.MskBxPeso.Location = new System.Drawing.Point(341, 178);
            this.MskBxPeso.Mask = "900.00";
            this.MskBxPeso.Name = "MskBxPeso";
            this.MskBxPeso.Size = new System.Drawing.Size(284, 39);
            this.MskBxPeso.TabIndex = 1;
            // 
            // MskBxAltura
            // 
            this.MskBxAltura.Location = new System.Drawing.Point(341, 258);
            this.MskBxAltura.Mask = " 0.00";
            this.MskBxAltura.Name = "MskBxAltura";
            this.MskBxAltura.Size = new System.Drawing.Size(284, 39);
            this.MskBxAltura.TabIndex = 2;
            // 
            // LblPeso
            // 
            this.LblPeso.AutoSize = true;
            this.LblPeso.Location = new System.Drawing.Point(210, 185);
            this.LblPeso.Name = "LblPeso";
            this.LblPeso.Size = new System.Drawing.Size(84, 32);
            this.LblPeso.TabIndex = 3;
            this.LblPeso.Text = "Peso";
            // 
            // LblAltura
            // 
            this.LblAltura.AutoSize = true;
            this.LblAltura.Location = new System.Drawing.Point(210, 265);
            this.LblAltura.Name = "LblAltura";
            this.LblAltura.Size = new System.Drawing.Size(96, 32);
            this.LblAltura.TabIndex = 4;
            this.LblAltura.Text = "Altura";
            // 
            // LblIMC
            // 
            this.LblIMC.AutoSize = true;
            this.LblIMC.Location = new System.Drawing.Point(121, 503);
            this.LblIMC.Name = "LblIMC";
            this.LblIMC.Size = new System.Drawing.Size(214, 32);
            this.LblIMC.TabIndex = 5;
            this.LblIMC.Text = "Resultado IMC";
            // 
            // MskBxIMC
            // 
            this.MskBxIMC.Location = new System.Drawing.Point(341, 496);
            this.MskBxIMC.Name = "MskBxIMC";
            this.MskBxIMC.ReadOnly = true;
            this.MskBxIMC.Size = new System.Drawing.Size(519, 39);
            this.MskBxIMC.TabIndex = 6;
            // 
            // BtnCalcular
            // 
            this.BtnCalcular.Location = new System.Drawing.Point(341, 374);
            this.BtnCalcular.Name = "BtnCalcular";
            this.BtnCalcular.Size = new System.Drawing.Size(284, 63);
            this.BtnCalcular.TabIndex = 7;
            this.BtnCalcular.Text = "CALCULAR";
            this.BtnCalcular.UseVisualStyleBackColor = true;
            this.BtnCalcular.Click += new System.EventHandler(this.BtnCalcular_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(17F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1081, 720);
            this.Controls.Add(this.BtnCalcular);
            this.Controls.Add(this.MskBxIMC);
            this.Controls.Add(this.LblIMC);
            this.Controls.Add(this.LblAltura);
            this.Controls.Add(this.LblPeso);
            this.Controls.Add(this.MskBxAltura);
            this.Controls.Add(this.MskBxPeso);
            this.Controls.Add(this.LblCalculeIMC);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblCalculeIMC;
        private System.Windows.Forms.MaskedTextBox MskBxPeso;
        private System.Windows.Forms.MaskedTextBox MskBxAltura;
        private System.Windows.Forms.Label LblPeso;
        private System.Windows.Forms.Label LblAltura;
        private System.Windows.Forms.Label LblIMC;
        private System.Windows.Forms.MaskedTextBox MskBxIMC;
        private System.Windows.Forms.Button BtnCalcular;
    }
}

