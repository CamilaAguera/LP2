﻿namespace PAtividade9
{
    partial class FormExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExercutar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnExercutar
            // 
            this.btnExercutar.Location = new System.Drawing.Point(373, 274);
            this.btnExercutar.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.btnExercutar.Name = "btnExercutar";
            this.btnExercutar.Size = new System.Drawing.Size(487, 147);
            this.btnExercutar.TabIndex = 0;
            this.btnExercutar.Text = "Executar";
            this.btnExercutar.UseVisualStyleBackColor = true;
            this.btnExercutar.Click += new System.EventHandler(this.btnExercutar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(38, 46);
            this.label1.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1097, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "string[] Alunos = {\"Viviane\", \"André\", \"Hélio\", \"Denise\", \"Junior\", \"Leonardo\", \"" +
    "Jose\", \"Nelma\", \"Tobby\"}; ";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(325, 155);
            this.lbl2.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(631, 32);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "Ao final do laço, podemos afirmar que Total vale:";
            // 
            // FormExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1138, 552);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnExercutar);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.Name = "FormExercicio3";
            this.Text = "FormExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExercutar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl2;
    }
}