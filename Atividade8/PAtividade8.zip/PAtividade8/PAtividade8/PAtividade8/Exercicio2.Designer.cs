﻿namespace PAtividade8
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNumN = new System.Windows.Forms.TextBox();
            this.lblNumN = new System.Windows.Forms.Label();
            this.btnCalcularH = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtNumN
            // 
            this.txtNumN.Location = new System.Drawing.Point(380, 72);
            this.txtNumN.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.txtNumN.Name = "txtNumN";
            this.txtNumN.Size = new System.Drawing.Size(260, 39);
            this.txtNumN.TabIndex = 2;
            // 
            // lblNumN
            // 
            this.lblNumN.AutoSize = true;
            this.lblNumN.Location = new System.Drawing.Point(180, 72);
            this.lblNumN.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lblNumN.Name = "lblNumN";
            this.lblNumN.Size = new System.Drawing.Size(142, 32);
            this.lblNumN.TabIndex = 1;
            this.lblNumN.Text = "Número N";
            // 
            // btnCalcularH
            // 
            this.btnCalcularH.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCalcularH.Location = new System.Drawing.Point(253, 248);
            this.btnCalcularH.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.btnCalcularH.Name = "btnCalcularH";
            this.btnCalcularH.Size = new System.Drawing.Size(199, 56);
            this.btnCalcularH.TabIndex = 3;
            this.btnCalcularH.Text = "Calcular H";
            this.btnCalcularH.UseVisualStyleBackColor = false;
            this.btnCalcularH.Click += new System.EventHandler(this.btnCalcularH_Click);
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(853, 466);
            this.Controls.Add(this.btnCalcularH);
            this.Controls.Add(this.lblNumN);
            this.Controls.Add(this.txtNumN);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.Name = "frmExercicio2";
            this.Text = "Exercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNumN;
        private System.Windows.Forms.Label lblNumN;
        private System.Windows.Forms.Button btnCalcularH;
    }
}