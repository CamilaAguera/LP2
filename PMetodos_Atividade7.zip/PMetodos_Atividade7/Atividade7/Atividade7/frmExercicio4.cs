﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnQtdeCarNum_Click(object sender, EventArgs e)
        {
            int i;
            int qtdeCaracteresNumericos;
            string mensagem;
            char posicao;

            qtdeCaracteresNumericos = 0;

            for (i=0; i < rchtxtFrase.Text.Length; i++)
            {
                posicao = rchtxtFrase.Text[i];
                if (Char.IsNumber(posicao))
                    qtdeCaracteresNumericos = qtdeCaracteresNumericos + 1;
            }
            mensagem = qtdeCaracteresNumericos.ToString();
            MessageBox.Show(mensagem);
        }

        private void btnPriCaracPosi_Click(object sender, EventArgs e)
        {
            int i;
            int emBranco;
            string mensagem;
            string mensagemNegativa;
            char posicao;

            i = 0;
            emBranco = 0;
            mensagemNegativa = "Não há espaços em branco";

            while (i < rchtxtFrase.Text.Length)
            {
                posicao = rchtxtFrase.Text[i];

                if (Char.IsWhiteSpace(posicao))
                {
                    emBranco = i + 1;
                    mensagem = emBranco.ToString();
                    MessageBox.Show(mensagem);
                    break;
                }
                else
                    i++;
            }
            if (i >= rchtxtFrase.Text.Length)
                MessageBox.Show(mensagemNegativa);
        }

        private void btnQtdeCarAlfa_Click(object sender, EventArgs e)
        {
            int qtdeCaracteresAlfabeticos;
            string mensagem;

            qtdeCaracteresAlfabeticos = 0;

            foreach(Char posicao in rchtxtFrase.Text)
            {
                if (Char.IsLetter(posicao))
                    qtdeCaracteresAlfabeticos = qtdeCaracteresAlfabeticos + 1;
            }
            mensagem = qtdeCaracteresAlfabeticos.ToString();
            MessageBox.Show(mensagem);
        }
    }
}
