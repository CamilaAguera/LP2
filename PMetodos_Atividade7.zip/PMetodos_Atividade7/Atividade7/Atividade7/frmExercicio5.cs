﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            int i;
            int num1;
            int num2;

            num1 = Convert.ToInt16(txtNumero1.Text);
            num2 = Convert.ToInt16(txtNumero2.Text);

            if (num1 < num2)
            {
                System.Random gerador = new System.Random();
                for (i = num1; i <= num2; i++)
                {
                    MessageBox.Show("Lançamento:" + i);
                    int numero = (gerador.Next(num1, num2));
                    if (numero==1||numero==10||numero==100||numero==1000)
                    {
                        MessageBox.Show("Parabéns você ganhou " + i + " lançamentos");
                        break;
                    }
                }
                MessageBox.Show("Jogue novamente");
            }
            else
            {
                MessageBox.Show("Número 1 precisa ser menor que o número 2");
                txtNumero1.Focus();
            }
        }
    }
}
