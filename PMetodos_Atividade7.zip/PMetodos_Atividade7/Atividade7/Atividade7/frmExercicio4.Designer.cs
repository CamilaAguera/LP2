﻿namespace Atividade7
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnQtdeCaractNum = new System.Windows.Forms.Button();
            this.btnPrimCaracPosi = new System.Windows.Forms.Button();
            this.btnQtdeCaracAlfab = new System.Windows.Forms.Button();
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnQtdeCaractNum
            // 
            this.btnQtdeCaractNum.Location = new System.Drawing.Point(18, 399);
            this.btnQtdeCaractNum.Margin = new System.Windows.Forms.Padding(9, 10, 9, 10);
            this.btnQtdeCaractNum.Name = "btnQtdeCaractNum";
            this.btnQtdeCaractNum.Size = new System.Drawing.Size(261, 250);
            this.btnQtdeCaractNum.TabIndex = 2;
            this.btnQtdeCaractNum.Text = "Quantidades de caracteres numéricos";
            this.btnQtdeCaractNum.UseVisualStyleBackColor = true;
            this.btnQtdeCaractNum.Click += new System.EventHandler(this.btnQtdeCarNum_Click);
            // 
            // btnPrimCaracPosi
            // 
            this.btnPrimCaracPosi.Location = new System.Drawing.Point(345, 399);
            this.btnPrimCaracPosi.Margin = new System.Windows.Forms.Padding(9, 10, 9, 10);
            this.btnPrimCaracPosi.Name = "btnPrimCaracPosi";
            this.btnPrimCaracPosi.Size = new System.Drawing.Size(261, 252);
            this.btnPrimCaracPosi.TabIndex = 3;
            this.btnPrimCaracPosi.Text = "Primeiro caracter em branco e sua posicão";
            this.btnPrimCaracPosi.UseVisualStyleBackColor = true;
            this.btnPrimCaracPosi.Click += new System.EventHandler(this.btnPriCaracPosi_Click);
            // 
            // btnQtdeCaracAlfab
            // 
            this.btnQtdeCaracAlfab.Location = new System.Drawing.Point(672, 399);
            this.btnQtdeCaracAlfab.Margin = new System.Windows.Forms.Padding(9, 10, 9, 10);
            this.btnQtdeCaracAlfab.Name = "btnQtdeCaracAlfab";
            this.btnQtdeCaracAlfab.Size = new System.Drawing.Size(261, 256);
            this.btnQtdeCaracAlfab.TabIndex = 4;
            this.btnQtdeCaracAlfab.Text = "Quantidades de caracteres alfabéticos";
            this.btnQtdeCaracAlfab.UseVisualStyleBackColor = true;
            this.btnQtdeCaracAlfab.Click += new System.EventHandler(this.btnQtdeCarAlfa_Click);
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(108, 70);
            this.rchtxtFrase.Margin = new System.Windows.Forms.Padding(9, 10, 9, 10);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(762, 288);
            this.rchtxtFrase.TabIndex = 1;
            this.rchtxtFrase.Text = "";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(21F, 40F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1145, 693);
            this.Controls.Add(this.rchtxtFrase);
            this.Controls.Add(this.btnQtdeCaracAlfab);
            this.Controls.Add(this.btnPrimCaracPosi);
            this.Controls.Add(this.btnQtdeCaractNum);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(9, 10, 9, 10);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnQtdeCaractNum;
        private System.Windows.Forms.Button btnPrimCaracPosi;
        private System.Windows.Forms.Button btnQtdeCaracAlfab;
        private System.Windows.Forms.RichTextBox rchtxtFrase;
    }
}