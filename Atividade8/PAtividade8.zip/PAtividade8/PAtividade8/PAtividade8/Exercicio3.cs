﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnPalin_Click(object sender, EventArgs e)
        {
            double entradaDouble;

            if(Double.TryParse(btnPalin.Text, out entradaDouble))
            {
                MessageBox.Show("Valor inválido");
                txtEntrada.Focus();
            }
            else
            {
                string s = txtEntrada.Text;
                string caixaAlta = s.ToUpper();
                string semEspacos = caixaAlta.Replace(" ", "");
                string sFinal = semEspacos;

                char[] arr = s.ToCharArray();
                Array.Reverse(arr);

                s = "";
                foreach(char c in arr)
                {
                    s=s+c.ToString();
                }

                string str = string.Join("", arr);
                string arrFinal = str.ToUpper();
                MessageBox.Show(sFinal);
                MessageBox.Show(arrFinal);

                if (String.Equals(sFinal, arrFinal))
                    MessageBox.Show("Sim é um palíndromo");
                else
                    MessageBox.Show("Não é um palíndromo");
            }

        }
    }
}
