﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            double peso, altura, imc;
            
            if(double.TryParse(MskBxPeso.Text, out peso) &&
                 double.TryParse(MskBxAltura.Text, out altura))
            { 
                imc = peso / Math.Pow(altura, 2);
                imc = Math.Round (imc, 1);
                
                
                if (imc < 18.5)
                    MskBxIMC.Text = "Seu imc é: " + imc.ToString() + " e a sua classificação é magreza ";

                else
                   if (imc <= 24.9)
                    MskBxIMC.Text = "Seu imc é: " + imc.ToString() + " e a sua classificação é normal ";
                
                else
                  if (imc <= 29.9)
                    MskBxIMC.Text= "Seu imc é: " + imc.ToString() + " e a sua classificação é sobrepeso ";

                else
                  if (imc <= 39.9)
                    MskBxIMC.Text = "Seu imc é: " + imc.ToString() + " e a sua classificação é obesidade ";

                else
                    MskBxIMC.Text = "Seu imc é: " + imc.ToString() + " e a sua classificação é obesidade grave ";
                MskBxPeso.Focus();

            }


        }

        private void MskBxPeso_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}
