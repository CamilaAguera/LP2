﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade9
{
    public partial class FormExercicio2 : Form
    {
        public FormExercicio2()
        {
            InitializeComponent();
        }

        private void btnLerDados_Click(object sender, EventArgs e)
        {
            string auxiliar;
            string auxiliar1;
            int[] vet1 = new int[10];
            double[] vet2 = new double[10];
            double[] vet3 = new double[10];
            double Acumulador;
            string mensagem;

            Acumulador = 0;

            for (var x = 0; x < 10; x++)
            {
                auxiliar = Interaction.InputBox("Digite a quantidade de Mercadoria " + (x + 1), "Entrada de Dados");
                if (!int.TryParse(auxiliar, out vet1[x]))
                {
                    MessageBox.Show("Valor inválido");
                    x -= 1;
                    continue;
                }
                auxiliar1 = Interaction.InputBox("Digite o preço da Mercadoria: " + (x + 1), "Entrada de Dados");
                if (!double.TryParse(auxiliar1, out vet2[x]))
                {
                    MessageBox.Show("Valor inválido");
                    x -= 1;
                    continue;
                }
            }
            auxiliar= "";
            auxiliar1= "";

            for (var x = 0; x < 10; x++)
            {
                vet3[x] = vet1[x] * vet2[x];
                Acumulador = Acumulador + vet3[x];
            }

            mensagem = Acumulador.ToString("N2");

            foreach (int i in vet1)
                auxiliar = auxiliar + "\n" + i;
            foreach (int i in vet2)
                auxiliar1 = auxiliar1 + "\n" + i;

            MessageBox.Show(mensagem, "Faturamento mensal: R$");
        }
    }
}
