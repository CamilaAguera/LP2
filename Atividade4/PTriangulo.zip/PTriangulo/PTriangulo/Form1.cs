﻿using System;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        private bool triagulo;

        public Form1()
        {
            InitializeComponent();
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            double ladoa, ladob, ladoc;


            if (double.TryParse(TxtLadoa.Text, out ladoa) &&
                double.TryParse(TxtLadob.Text, out ladob) &&
                double.TryParse(TxtLadoc.Text, out ladoc))
            {
               
                if ((ladoa < (ladob + ladoc) && (ladoa > Math.Abs(ladob - ladoc))))
                {
                    MskbxModelo.Text = "Triângulo Equilatero" + MskbxModelo.ToString();
                }
                else
                    if ((ladob < (ladoa + ladoc) && (ladob > Math.Abs(ladoa - ladoc))))
                    MskbxModelo.Text = "Triângulo Isosceles" + MskbxModelo.ToString();

                else
                    MskbxModelo.Text = "Triângulo Equaleno" + MskbxModelo.ToString();
                TxtLadoa.Focus();






            }

        }

        private void TxtLadoa_Validated(object sender, EventArgs e)
        {
            double ladoa;

            if(!double.TryParse(TxtLadoa.Text, out ladoa))
            {

                MessageBox.Show("Peso Invalido");
            }

        }
    }
}
