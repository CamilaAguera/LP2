﻿namespace Atividade7
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.btnRemOco = new System.Windows.Forms.Button();
            this.lblPalavra2 = new System.Windows.Forms.Label();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.btnRemOcoRep = new System.Windows.Forms.Button();
            this.btnInvert = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(117, 48);
            this.lblPalavra1.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(169, 40);
            this.lblPalavra1.TabIndex = 1;
            this.lblPalavra1.Text = "Palavra 1";
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.Location = new System.Drawing.Point(384, 58);
            this.txtPalavra1.Margin = new System.Windows.Forms.Padding(9, 10, 9, 10);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(340, 48);
            this.txtPalavra1.TabIndex = 2;
            // 
            // btnRemOco
            // 
            this.btnRemOco.Location = new System.Drawing.Point(36, 351);
            this.btnRemOco.Margin = new System.Windows.Forms.Padding(9, 10, 9, 10);
            this.btnRemOco.Name = "btnRemOco";
            this.btnRemOco.Size = new System.Drawing.Size(261, 172);
            this.btnRemOco.TabIndex = 2;
            this.btnRemOco.Text = "Remove ocorrências";
            this.btnRemOco.UseVisualStyleBackColor = true;
            this.btnRemOco.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblPalavra2
            // 
            this.lblPalavra2.AutoSize = true;
            this.lblPalavra2.Location = new System.Drawing.Point(117, 179);
            this.lblPalavra2.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.lblPalavra2.Name = "lblPalavra2";
            this.lblPalavra2.Size = new System.Drawing.Size(169, 40);
            this.lblPalavra2.TabIndex = 3;
            this.lblPalavra2.Text = "Palavra 2";
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.Location = new System.Drawing.Point(384, 179);
            this.txtPalavra2.Margin = new System.Windows.Forms.Padding(9, 10, 9, 10);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(340, 48);
            this.txtPalavra2.TabIndex = 4;
            // 
            // btnRemOcoRep
            // 
            this.btnRemOcoRep.Location = new System.Drawing.Point(353, 351);
            this.btnRemOcoRep.Margin = new System.Windows.Forms.Padding(9, 10, 9, 10);
            this.btnRemOcoRep.Name = "btnRemOcoRep";
            this.btnRemOcoRep.Size = new System.Drawing.Size(261, 172);
            this.btnRemOcoRep.TabIndex = 5;
            this.btnRemOcoRep.Text = "Remove ocorrêcias (replase)";
            this.btnRemOcoRep.UseVisualStyleBackColor = true;
            this.btnRemOcoRep.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnInvert
            // 
            this.btnInvert.Location = new System.Drawing.Point(693, 341);
            this.btnInvert.Margin = new System.Windows.Forms.Padding(9, 10, 9, 10);
            this.btnInvert.Name = "btnInvert";
            this.btnInvert.Size = new System.Drawing.Size(261, 172);
            this.btnInvert.TabIndex = 6;
            this.btnInvert.Text = "Inverter primeira palavra (reverse)";
            this.btnInvert.UseVisualStyleBackColor = true;
            this.btnInvert.Click += new System.EventHandler(this.button3_Click);
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(21F, 40F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1040, 603);
            this.Controls.Add(this.btnInvert);
            this.Controls.Add(this.btnRemOcoRep);
            this.Controls.Add(this.txtPalavra2);
            this.Controls.Add(this.lblPalavra2);
            this.Controls.Add(this.btnRemOco);
            this.Controls.Add(this.txtPalavra1);
            this.Controls.Add(this.lblPalavra1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(9, 10, 9, 10);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPalavra1;
        private System.Windows.Forms.TextBox txtPalavra1;
        private System.Windows.Forms.Button btnRemOco;
        private System.Windows.Forms.Label lblPalavra2;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.Button btnRemOcoRep;
        private System.Windows.Forms.Button btnInvert;
    }
}