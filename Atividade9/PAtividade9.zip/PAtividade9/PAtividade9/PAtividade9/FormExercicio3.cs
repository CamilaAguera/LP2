﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade9
{
    public partial class FormExercicio3 : Form
    {
        public FormExercicio3()
        {
            InitializeComponent();
        }

        private void btnExercutar_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            string Total2;

            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
               Total2 = Total.ToString();
                MessageBox.Show(Total2);
            }
        }
    }
}
