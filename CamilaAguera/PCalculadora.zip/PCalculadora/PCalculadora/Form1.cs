﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        private double numero1, numero2, resultado;  //globais

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(textBox2.Text, out numero2)) 
            MessageBox.Show("número inválido");
            if (textBox2.Text == "") 
            MessageBox.Show("Inserir o numero");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out numero1) &&
            double.TryParse(textBox2.Text, out numero2)) 
            {
                resultado = numero1 + numero2;
                textBox3.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Numeros inválidos!!");
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out numero1) &&
           double.TryParse(textBox2.Text, out numero2)) 
            {
                resultado = numero1 - numero2;
                textBox3.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Numeros inválidos!!");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out numero1) &&
           double.TryParse(textBox2.Text, out numero2)) 
            {
                resultado = numero1 * numero2;
                textBox3.Text = resultado.ToString();
            }
            else
                MessageBox.Show("Numeros inválidos!!");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out numero1) &&
           double.TryParse(textBox2.Text, out numero2)) 
            {
                if (numero2 == 0)
                    MessageBox.Show("Não pode dividir por zero!");
                else
                {
                    resultado = numero1 / numero2;
                    textBox3.Text = resultado.ToString();
                }
            }
            else
                MessageBox.Show("Numeros inválidos!!"); ;
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";

            textBox1.Focus();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textBox1.Text, out numero1))
               MessageBox.Show("número inválido"); 
            if (textBox1.Text == "")
               MessageBox.Show("Inserir o numero");


        }
    }
}
