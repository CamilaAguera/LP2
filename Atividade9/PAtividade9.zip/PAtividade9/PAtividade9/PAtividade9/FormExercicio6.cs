﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade9
{
    public partial class FormExercicio6 : Form
    {
        public FormExercicio6()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            
            string auxiliar;
            string auxiliar1;
            double[] entrada = new double[10];
            double[] saida = new double[10];
            int tamanho;

            for (var x = 0; x < 10; x++)
            {
                auxiliar = Interaction.InputBox("Digite um nome " + (x + 1), "Entrada de Dados");
                if (double.TryParse(auxiliar, out entrada[x]))
                {
                    MessageBox.Show("Valor inválido");
                    x -= 1;
                    auxiliar = entrada[x].ToString();
                }
                else
                {
                    auxiliar1 = auxiliar.Replace(" ", "");
                    tamanho = auxiliar1.Length;
                    saida[x] = tamanho;
                    listBox.Items.Add("O nome: " + auxiliar + " tem " + saida[x].ToString() + " caracteres");
                }
                auxiliar = "";
            }
        }

    }
}

